# Pools
Pools is an asset that will allow you to easily create a pool of objects. This will not waste memory and will also save the performance of your game.

![54fd4cc0-d07e-4a6b-8acd-390231dab610](https://user-images.githubusercontent.com/5365111/185044246-99b9e6c5-8611-4c47-b899-45eeb639a91c.jpg)

Select documentation language:
* <a href="https://github.com/KurbanismailovZaur/Pools/blob/master/Docs/Readme_EN.md">English documentation</a>
* <a href="https://github.com/KurbanismailovZaur/Pools/blob/master/Docs/Readme_RU.md">Русская документация</a>
